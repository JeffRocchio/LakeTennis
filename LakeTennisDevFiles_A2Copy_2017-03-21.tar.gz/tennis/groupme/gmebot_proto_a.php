<?php
/*
	This script is for prototyping/testing of a GroupMe Bot.
	This is the callback function.
	
	12/12/2016 Version 0.1 --
------------------------------------------------------------------ */
session_start();
include_once('../INCL_Tennis_CONSTANTS.php');
include_once('../INCL_Tennis_Functions_Session.php');
include_once('../INCL_Tennis_DBconnect.php');
include_once('../INCL_Tennis_Functions.php');
include_once('../INCL_Tennis_Functions_ADMIN_v2.php');
include_once('../classdefs/error.class.php');
include_once('../classdefs/debug.class.php');
include_once('../clsdef_mdl/database.class.php');
include_once('../clsdef_mdl/simulatedRecordset.class.php');
include_once('../clsdef_mdl/recordset.class.php');
include_once('../clsdef_mdl/series.class.php');
include_once('../clsdef_mdl/event.class.php');
include_once('../clsdef_mdl/rsvp.class.php');
include_once('../clsdef_mdl/autoAction.class.php');
include_once('../clsdef_mdl/link.class.php');
include_once('../clsdef_mdl/txtBlock.class.php');
include_once('../clsdef_view/eventViewChunks.class.php');
include_once('../clsdef_view/html2text.class.php');
include_once('../clsdef_view/linkViews.class.php');
include_once('../clsdef_ctrl/emailNotice.class.php');
include_once('../clsdef_ctrl/eventViewRequests.class.php');
include_once('../clsdef_ctrl/viewFromTemplate.class.php');
include_once('../clsdef_ctrl/txtBlockViewRequests.class.php');
include_once('../clsdef_ctrl/autoActionHandler.class.php');
include_once('../clsdef_ctrl/rsvpUpdateViaEmailLink.class.php');
include_once('../INCL_Tennis_GLOBALS.php');
Session_Initalize();

$rtnpg = Session_SetReturnPage();


//----USEFUL GLOBAL VARIABLES-------------------------------------------------->
$LineFeed = "<BR>";
$OpenPara = "<P>";
$ClosePara = "</P>";
$nbSpace = NBSP;
$indent = $nbSpace . $nbSpace . $nbSpace;

				//   For knowing if we are running in Web-Browser vs CRON.
				//I am assuming GroupMe call-backs run in a virtual browser.
$RunningInCron = TRUE;
$RunningInCron = FALSE;



//----DECLARE SCRATCH VARIABLES------------------------------------------------>
	$message = "";
	
	
//----DETERMINE RUN ENVIRONMENT------------------------------------------------>
$RunningInCron = !isset($_SERVER['HTTP_HOST']);
if ($RunningInCron)
	{
	$LineFeed = LF;
	$OpenPara = LF;
	$ClosePara = LF;
	$nbSpace = " ";
	$indent = $nbSpace . $nbSpace . $nbSpace;
	}


//----CONNECT TO MYSQL-------------------------------------------------------->
$link = Tennis_DBConnect();
if ($lstErrExist == TRUE)
	{
	echo "<P>{$lstErrMsg}</P>";
	include './INCL_footer.php';
	exit;
	}


//----OPEN DISPLAY/NOTICE OUTPUT "PAGE"---------------------------------------->
				//   Set page header text and create the page, being sensitive
				//to what run environment we are in.
$tbar = "Process Auto Actions";
$pgL1 = "GroupMe Bot Callback";
$pgL2 = "";
$pgL3 = "Processing Bot Response";
if ($RunningInCron)
	{
	$outText = $tbar . $LineFeed;
	$outText .= $pgL1 . $LineFeed;
	$outText .= $pgL2 . $LineFeed;
	$outText .= $pgL3;
	dm($outText);
	}
else
	{
	echo Tennis_BuildHeader('ADMIN', $tbar, $pgL1, $pgL2, $pgL3);
	}
				//   With page 'open', output any pending info or notices.
$outText = "NOTE: We are Running In ";
if ($RunningInCron) { $outText .= "CRON."; }
else { $outText .= "WEB BROWSER."; }
dm($outText);

//==============================================================================
//   Process Callback and Determine Bot Action, If Any
//==============================================================================


	global $objError;
	global $objDebug;

	$objDebug->DEBUG = FALSE;
//	$objDebug->DEBUG = TRUE;

	//	Attempt to get the message params.
	$url = "php://input";
	$result = file_get_contents($url);
	$data = json_decode($result, true);	 

	//$sBotMessage = "default+message";
	$sBotID = "bot_id=003fd303e76983b6cbe976409f";
	//$results = print_r($_POST, true);
	$sBotMessage = "text=You+Are:+{$data['name']}";

	//	Get message post data.
	if ($data["name"] <> "JrocDevBot")
		{
		$sPostURL = "https://api.groupme.com/v3/bots/post";
		$iPostFieldCount = 2;
		$sPostFieldString = "{$sBotID}&{$sBotMessage}";
		echo "<P>{$sPostFieldString}</P>";
		
		echo "<P>Sending message</P>";
		// create a new cURL resource
		$ch = curl_init();
	
		// set URL and other appropriate options
		curl_setopt($ch,CURLOPT_POST,$iPostFieldCount);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$sPostFieldString);
		curl_setopt($ch, CURLOPT_URL, $sPostURL);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		
		//execute the post
		$callResponse = curl_exec($ch);
		echo("<P>");
		echo($callResponse);
		echo("</P>");
		
		// close cURL resource, and free up system resources
		curl_close($ch);
		echo "<P>message sent</P>";
		}
			

//----CLOSE OUT THE DISPLAY/NOTICE OUTPUT "PAGE"------------------------------->

	echo  Tennis_BuildFooter('ADMIN', "");


//==============================================================================
// Utility Functions
//==============================================================================

function dm($displayText, $newPara=TRUE)
					//Display a message on the console.
	{
	global $CRLF;
	global $LineFeed;
	global $OpenPara;
	global $ClosePara;
	global $nbSpace;
	global $indent;

	if($newPara) $textToDisplay = $OpenPara . $displayText . $ClosePara;
	else $textToDisplay = $displayText;
	echo $textToDisplay;
	return;
	}


?> 
