<?php

echo "<P>&nbsp;</P><HR>";

echo "<p><font size='-1'><b><A HREF='../ClubHome.php'>HOME</A></b></font></p>";

echo "</body>";
echo "</html>";

?>
