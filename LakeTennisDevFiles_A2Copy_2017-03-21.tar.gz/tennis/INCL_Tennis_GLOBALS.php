<?php

/*
	Contains variable declarations that are meant to be global in scope.
	REMEMBER: Within a function you do need to use the 'global' declaration
	to pull these into scope.
	
*/
//GLOBAL OBJECTs:

$objError = new ErrorList();

$objDebug = new debug();


?>
